// src/components/challenge-detail/index.ts
// Exports for Challenge Detail Screen

export { ChallengeDetailScreen } from "./ChallengeDetailScreen";
export type { ChallengeDetailScreenProps } from "./ChallengeDetailScreen";
