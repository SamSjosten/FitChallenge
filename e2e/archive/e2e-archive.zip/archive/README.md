# E2E Test Archive — Reference Test Plans

**Archived:** February 2026
**Reason:** These tests were scaffolded against a different helper system (`e2e/utils/`) with incorrect credentials and stale testIDs. They have never passed against the live app.

**The working E2E suite lives in `e2e/*.e2e.ts`** using helpers from `e2e/setup.ts`.

---

## What's Here

| File | Coverage Area | Test Count | Value |
|------|--------------|------------|-------|
| `tests/friends.e2e.ts` | Friend requests, accept/decline, multi-user flow | 16 | **High** — no root coverage |
| `tests/offline.e2e.ts` | Offline detection, cached data, queue sync, idempotency | 12 | **High** — no root coverage |
| `tests/health.e2e.ts` | HealthKit connection, sync, permissions, disconnect | 14 | **High** — no root coverage |
| `tests/profile.e2e.ts` | Profile display, edit, settings navigation | 8 | **Medium** — partial root coverage |
| `tests/auth.e2e.ts` | Signup validation, password reset | 18 | **Medium** — partial root coverage |
| `tests/challenges.e2e.ts` | Challenge list, detail, filtering | 17 | **Low** — mostly covered by root suite |
| `utils/testHelpers.ts` | goOffline/goOnline, scroll, swipe, orientation | — | **Cherry-pick target** |
| `utils/authHelpers.ts` | completeOnboarding, skipOnboardingIfPresent | — | **Cherry-pick target** |

---

## How to Use These

**When building new E2E tests**, open the relevant archive file to see which scenarios were planned. Then write fresh tests using the root `e2e/setup.ts` helpers.

Example workflow for adding friends E2E coverage:

```
1. Read e2e/archive/tests/friends.e2e.ts for test case ideas
2. Write new tests in e2e/friends.e2e.ts importing from e2e/setup.ts
3. Cherry-pick any needed helpers (e.g., multi-user switching) into setup.ts
```

**Do NOT try to run these files directly.** They reference:
- Wrong credentials (`e2e-primary@fitchallenge-test.com` / `TestPass123!`)
- Wrong testIDs (V1 screen names, missing entries)
- Helper signatures that don't match `setup.ts`

---

## Helpers Worth Cherry-Picking Later

From `utils/testHelpers.ts`:
- `goOffline()` / `goOnline()` — device network simulation
- `scrollToElement()` — scroll within a container until element visible
- `backgroundAndForeground()` — app lifecycle testing
- `longPressElement()` — long press with duration
- `swipeLeft()` / `swipeRight()` — gesture testing
- `setOrientation()` — rotation testing
- `dismissKeyboard()` — keyboard management

From `utils/authHelpers.ts`:
- `completeOnboarding()` — step through onboarding flow
- `skipOnboardingIfPresent()` — conditional skip
- `signUpNewUser()` — timestamp-unique signup for isolation
- `assertFieldError()` / `assertSignInError()` — error assertion patterns
